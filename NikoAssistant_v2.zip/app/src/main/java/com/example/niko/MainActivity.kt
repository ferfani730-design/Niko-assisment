package com.example.niko

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var input: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 70, 40, 30)
        }
        val title = TextView(this).apply {
            text = "🤖 نیکو"
            textSize = 32f
            setPadding(0,0,0,20)
        }
        status = TextView(this).apply {
            text = "سلام! من نیکو هستم. با من صحبت کن."
            textSize = 20f
            setPadding(0,0,0,25)
        }
        input = EditText(this).apply { hint = "پیامت را بنویس..." }

        val send = Button(this).apply {
            text = "فرستادن"
            setOnClickListener { answer(input.text.toString()) }
        }
        val voice = Button(this).apply {
            text = "🎙️ صحبت با نیکو"
            setOnClickListener { startVoice() }
        }

        box.addView(title); box.addView(status); box.addView(input); box.addView(send); box.addView(voice)
        setContentView(box)
    }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10); return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-AF")
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        startActivityForResult(i, 11)
    }

    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 11 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            input.setText(text)
            answer(text)
        }
    }

    private fun answer(text: String) {
        if (text.isBlank()) return
        val reply = "شنیدم: $text. نسخهٔ اول نیکو آماده است؛ در مرحلهٔ بعد می‌توانیم هوش مصنوعی واقعی را به آن وصل کنیم."
        status.text = reply
        speak(reply)
    }

    private fun speak(text:String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "niko")
    }

    override fun onInit(result:Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale("fa", "AF")
            val voices = tts.voices?.filter { it.locale.language == "fa" }
            voices?.firstOrNull { it.name.contains("male", true) }?.let { tts.voice = it }
        }
    }

    override fun onDestroy() {
        tts.stop(); tts.shutdown(); super.onDestroy()
    }
}
