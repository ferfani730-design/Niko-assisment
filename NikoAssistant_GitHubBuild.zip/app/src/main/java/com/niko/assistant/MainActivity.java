package com.niko.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    TextToSpeech tts;
    EditText input;
    public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32,32,32,32);

        TextView title = new TextView(this);
        title.setText("Niko 🤖");
        title.setTextSize(30);
        box.addView(title);

        TextView msg = new TextView(this);
        msg.setText("سلام! من نیکو هستم. پیام خودت را بنویس.");
        msg.setTextSize(18);
        box.addView(msg);

        input = new EditText(this);
        input.setHint("پیامت را بنویس...");
        box.addView(input);

        Button speak = new Button(this);
        speak.setText("🔊 نیکو جواب بده");
        box.addView(speak);

        setContentView(box);

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("fa"));
        });

        speak.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (text.isEmpty()) text = "سلام! من نیکو هستم. خوشحالم که با من صحبت می‌کنی.";
            msg.setText("نیکو: " + text);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "niko");
        });
    }

    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
